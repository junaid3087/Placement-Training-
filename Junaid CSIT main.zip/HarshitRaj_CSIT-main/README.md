Weekly screenshots added in Folders
